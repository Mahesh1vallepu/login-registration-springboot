package com.project.loginForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
